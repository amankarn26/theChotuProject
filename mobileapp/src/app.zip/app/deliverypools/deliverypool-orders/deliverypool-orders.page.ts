import { RestService } from './../../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-deliverypool-orders',
  templateUrl: './deliverypool-orders.page.html',
  styleUrls: ['./deliverypool-orders.page.scss'],
})
export class DeliverypoolOrdersPage implements OnInit {

  status: string;
  title: string;
  orders: any[] = [];
  detailFlag = false;


  orderItems: any;
  userotp = '';
  otp = '';

  public docServer = this.restService.docServer;
  constructor(private router: Router,
    private restService: RestService,
    public toastController: ToastController,
    public routprms: ActivatedRoute,
    public alertController: AlertController,) {
    // this.getOrders();
  }

  ngOnInit() {

    // Read parameter from route
    console.log(this.routprms.snapshot.params.status);
    this.status = this.routprms.snapshot.params.status;
    //  if (this.route.url === '/vendor-orders/' + encodeURIComponent(this.status)) {
    //   this.title = 'Update Customer ';
    //   this.subtitle = 'Edit customer  details.';
    //   this.flag = true;
    //   //  this.getAllDept();
    // } else if
    if (this.status === 'PACKED') {
      this.title = 'Packed Orders';
      this.getOrders();
    } else if (this.status === 'PICKED_UP') {
      this.title = 'Pickuped Orders';
      this.getOrders();
    } else if (this.status === 'DELIVERED') {
      this.title = 'Delivered Orders';
      this.getOrders();
    } else{
      this.title = 'Inactive Orders';
      this.getOrders();
    }
  }


  getOrders() {
    let qerystr = '?person=' + localStorage.getItem('id')+'&status=' + this.status;
    // if (this.status === 'ACTIVE') {
    //   qerystr = qerystr + '&active=YES';
    // } else if(this.status === 'CLOSED') {
    //   qerystr = qerystr + '&active=NO';
    // }else if(this.status === 'ALL') {
    //   qerystr = '?firm=' + localStorage.getItem('firm') + '&index=1&limit=100';
    // }else{
    //   qerystr = qerystr + '&status=' + this.status;
    // }

    // Get Information from JSON REST api
    // http://localhost:8090/SmartSupplyManager/rest/order?person=67&status=PACKED  -- pool id

    const url = this.restService.compactRestURL('ordersbydeliverypool', qerystr);
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.orders = response;
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  isOrders(): boolean {
    return this.orders.length == 0 ? false : true;
  }

  ordersDetails(index: any, id: any) {
    console.log('index' + index);
    console.log('id' + id);
    this.detailFlag = true;
    this.orderItems = this.orders[index];
  }

  cancel() {
    this.detailFlag = false;
    this.router.navigate(['/deliverypools/deliverypool-orders/' + status]);
  }


  changeStatus(STATUS: any, id: any) {

    if(STATUS ==='PICKED_UP'){
      this.updatingStatus(STATUS, id)

    }else{

      this.generateotp();
      this.presentToast('OTP Send=' + this.otp);
      this.presentPrompt(STATUS, id);

    }
  }

  updatingStatus(STATUS: any, id: any){
    this.presentToast('OTP Send=' + this.otp);


    let order = {
      id: id,
      status: STATUS
    };
    console.log('update function');
    console.log(order);
    const url = this.restService.compactRestURL('updateorder', '');
    this.restService.postFormData(url, order).subscribe(
      response => {
        // Responce data.
        console.log('Status on Post API');
        console.log(response);
        this.presentToast('Order Picked Up');
        this.getOrders();
        this.cancel();
      },
      error => {
        // Error Message
        this.presentToast('Failed To Picked Up');
        console.log('Error in data load.');
        // Doyour stuff here
      }
    );
    return 0;
  }


  generateotp() {
    this.otp = String(Math.floor(100000 + Math.random() * 900000)); // this.generatepassword;

    console.log('OTP='+this.otp);

  }

  async presentToast(msg: any) {
    const toast = await this.toastController.create({
      message: msg,
      // position: 'top',
      // animated: true,
      duration: 2000
    });
    toast.present();
  }


  async presentPrompt(STATUS: any, id: any) {
    // console.log('Inside Prompt');
    const alert = await this.alertController.create({
      header: 'Verify OTP',
      inputs: [
        {
          name: 'OTP',
          placeholder: '_ _ _ _ _ _'
        }
      ],
      buttons: [
        {
          text: 'Resend OTP',
          // role: 'cancel',
          handler: data => {
          this.resend();
          }
        },
        {
          text: 'Verify',
          handler: data => {


            console.log('verfifying otp');
            console.log('this.otp '+this.otp);
            console.log('data.otp'+data.otp);
            console.log(data);

            if (Number(this.otp) == Number(data.OTP)) {
              // logged in!
              console.log(this.otp);
              // console.log(this.userotp);
              this.presentToast('OTP Verified');
              this.updatingStatus(STATUS, id);
              // if (this.segment === 'CUSTOMER') {
              //   this.submitData();
              // } else   if (this.segment === 'FIRM') {
              //   this.submitData1();
              // } else   if (this.segment === 'DELIVARY_PERSON') {
              //   this.submitData2();
              // }
            } else {
              // invalid login
              this.presentToast('Failed to Verify');
              return false;
            }
          }
        }
      ]
    });
    await alert.present();
  }


  resend(){
    this.generateotp();
    this.presentToast('OTP Send=' + this.otp);
  }
}
