import { CartService } from './../cart.service';
import { Component, OnInit } from '@angular/core';
declare var Razorpay: any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage implements OnInit {
  selectedItems = [];
  total = 0;
  deliverycharges = 30;
  grandtotal = 0;



  // payment json
  options = {
    "key": "rzp_test_BFZPuXGalgBJ1L", // Enter the Key ID generated from the Dashboard
    "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "iNouvelle Ventures Pvt. Ltd.",
    "description": "Test Transaction",
    "image": "http://inouvelle.com/images/inouvelle_logo.png",
    "handler": function (response){
      alert(response.razorpay_payment_id);
      // alert(response.razorpay_order_id);
      // alert(response.razorpay_signature)
  },
    "prefill": {
      "name": "Pankaj Chaudhari",
      "email": "pankaj_chaudhari@example.com",
      "contact": "9999999999"
  },
  "notes": {
      "address": "Razorpay Corporate Office"
  },
  "theme": {
      "color": "#F37254"
  }
};


  constructor(private cartService: CartService) { }

  ngOnInit() {
    let items = this.cartService.getCart();
    let selected = {};

    for (let obj of items) {

      //  selected[obj.id] = { ...obj, count: obj.quantity };

      if (selected[obj.id]) {
        console.log('selected[obj.id].count=' + selected[obj.id].count);
        console.log('obj.quantity=' + obj.quantity);
        selected[obj.id].count = parseFloat(selected[obj.id].count) + parseFloat(obj.quantity);
        console.log('selected[obj.id].count=' + selected[obj.id].count);
        console.log('obj.quantity=' + obj.quantity);
      } else {
        selected[obj.id] = { ...obj, count: obj.quantity };
      }





      // if (selected[obj.id]) {
      //   selected[obj.id].count++;
      // } else {
      //   selected[obj.id] = { ...obj, count: 1 };
      // }
    }

    this.selectedItems = Object.keys(selected).map(key => selected[key])
    console.log('items:', this.selectedItems);
    this.total = this.selectedItems.reduce((a, b) => a + (b.count * b.price), 0);

    this.grandtotal = this.total + this.deliverycharges;
  }


  initPay() {
    var rzp1 = new Razorpay(this.options);
    rzp1.open();
    console.log("works");
  }

}
