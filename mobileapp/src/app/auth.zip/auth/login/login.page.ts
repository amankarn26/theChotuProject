import { RestService } from './../../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { ToastController } from '@ionic/angular';
// import { AlertController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {


  login = {
    username: '',
    password: '',

  };
  isLoggedin = false;
  constructor(
    public route: Router,
    public routprms: ActivatedRoute,
    private restService: RestService,
    // private toastCtrl: ToastController,
    public alertController: AlertController,
    public toastController: ToastController
  ) {


    if(localStorage.getItem('islogin') == 'true'){
      this.route.navigate(['/tabs/tab1']);
    }
  }

  ngOnInit() {


  }


  ionViewWillEnter() {
    if(localStorage.getItem('islogin') == 'true'){
      this.route.navigate(['/tabs/tab1']);
    }
    console.log('ionViewWillEnter ');  // called on first time
  }

  submitData() {

    //  alert('login click');
    // this.route.navigate(['/home']);
    // localStorage.setItem('isLoggedin', 'YES');
    //  this.presentToast();
    this.loginFunc();

  }


  async presentAlert() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Alert',
      subHeader: 'Subtitle',
      message: 'This is an alert message.',
      buttons: ['OK']
    });

    await alert.present();
  }

  async presentToast(msg: any) {
    const toast = await this.toastController.create({
      message: msg,
      // position: 'top',
      // animated: true,
      duration: 2000
    });
    toast.present();
  }

  loginFunc() {

    if ((this.login.username !== '') && (this.login.password !== '')) {
      // login code start**************************************************************************************
      console.log('submitData function');
      console.log(this.login);
      const url = this.restService.userRestURL('login', '');
      this.login.password = window.btoa(this.login.password); // added on 5/1/2019
      this.restService.postFormData(url, this.login).subscribe(
        (response: any) => {
          // Responce data.
          console.log('Status on Post API');
          console.log(response);
          // licensed expiry code
          let firm;
          // let expiredon = new Date(this.unixTimeConverter(response.expiredon));
          // let todaydate = this.todatDate(); // new Date();
          // let d1 = new Date(todaydate);
          // let d2 = new Date(expiredon);
          // if (d1 < d2) {
          // } else {
          //  Swal.fire('Your Demo Expired', 'Please, Contact Invouelle Ventrues Pvt. Ltd. For Reneual', 'error');
          // }
          // // end licenses expiry code
          // if (response.role.role !== 'NO_ACCESS' && d1 < d2) {
          if (response.login.role !== 'NO_ACCESS') {

            localStorage.setItem('id', response.id);
            localStorage.setItem('name', response.name);
            localStorage.setItem('role', response.login.role);
            localStorage.setItem('type', response.login.type);
            localStorage.setItem('islogin', 'true');
            localStorage.setItem('islogin', 'true');
            localStorage.setItem('email', response.email);
            localStorage.setItem('phone', response.phone);
            localStorage.setItem('Address', JSON.stringify(response.address));


            if (response.photo) {
              sessionStorage.setItem('photo', response.photo.docpath);
            }
            if (response.phone) {
              sessionStorage.setItem('phone', response.phone);
            }

            this.isLoggedin = true;
            // location.reload();
            this.presentToast('Loggedin Successful');
            if (response.login.type === 'FIRM') {
              firm = response.id;
              localStorage.setItem('firm', firm);
              localStorage.setItem('category', response.category);
              // this.getsysconfig(firm);
              localStorage.setItem('photo', response.logo.docpath);
             // this.route.navigate(['/vendors']);
              this.route.navigate(['/vendors/vendor-home']);
            } else  if (response.login.type === 'CUSTOMER') {
              this.route.navigate(['/tabs']);
              // location.reload();
            }else  if (response.login.type === 'DELIVERY_PERSON') {
              this.route.navigate(['/deliverypools/deliverypool-home']);
              // location.reload();
            }
          }
        },
        error => {
          // Error Message
          console.log('Error in data load.');
          this.presentToast('Yusername or password does not match');
          // Swal.fire(
          //   'Invalid user ID or Password',
          //   '',
          //   'error'
          // );

        }
      );
      return 0;

      // login code end***************************************************************************************
      //  location.reload();

    } else {
      // Swal.fire(
      //   'Please provide user ID and Password.',
      //   '',
      //   'error'
      // );
    }
  }


}
