import { RestService } from './../../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { ToastController } from '@ionic/angular';
// import { AlertController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  user = {
    phone: '',
    name:'',
    gender:'',
    dob:'',
    email:'',
    city: '',
    address: {
      line1: '',
      line2: '',
      city: '',
      pincode: '',
      states: '',
      country: 'India'
    },
    login: {
      type: 'CUSTOMER',
      username: '', // ----------User name can be phone or email
      password: '',
      role: 'CUSTOMER'
    },

  };

  isotpverified = false;

  userotp = '';

  otp = '';

  segment = 'CUSTOMER';
  firmid;

  public file;
  public file1;

  public firm = {
    name: '',
    // regno: '',
    category:'',
    phone: '',
    email: '',
    code: '',
    empcount: '',
    pannum: '',
    gstin: '',
    address: {
      line1: '',
      line2: '',
      pincode: '',
      states: '', // [this.getStateList()],
      city: '', // [this.getCityList('Maharashtra')],
      country: 'India'
    },
    account: {
      type: '',    // --enum BANK/PAYTM/GOOGLE_PAY
      acctnumber: '',
      branch:'',    // --if type=BANK
      ifsccode:'',  //    --if type=BANK
      city:''      // --if type=BANK
    },
    login: {
      type: 'FIRM',
      username: '', // ----------User name can be phone or email
      password: '',
      role: 'FIRM'
    },
    usedeliverypool: 'NO',
    servicerate: ''
  };

  // statelist = [];
  // citylist = [];

  categoryList = [];



  private photo = { docName: '', docpath: '', docdesc: '', docType: '', isprimary: 'YES' };

  document;
  public urls;
  public urls1;


  delivery = {
        // state: '',
        // city: '',
        name: '',
        phone: '',
        email: '',
    login: {
      type: 'DELIVERY_PERSON',
      username: '', // ----------User name can be phone or email
         password: '',
      role: 'DELIVERY_PERSON'
    },
    address: {
      line1: '',
      line2: '',
      city: '',
      pincode: '',
      states: '',
      country: 'India'
    },
      vehicletype: '',
      // vehiclereg: '',
      // license: '',
    status: 'PENDING',
  };

  pincode;

  gstpan ='NO';


  document1;
  document2;


   license = { docName: '', docpath: '', docdesc: '', docType: '', isprimary: 'YES' };
   vehiclereg = { docName: '', docpath: '', docdesc: '', docType: '', isprimary: 'YES' };

   deliverypoolid;

  constructor(public route: Router,
    public routprms: ActivatedRoute,
    private restService: RestService,
    // private toastCtrl: ToastController,
    public alertController: AlertController,
    public toastController: ToastController
  ) { }

  ngOnInit() {


    this.generatepass();
    this.getCatlist();

  }




  async presentToast(msg: any) {
    const toast = await this.toastController.create({
      message: msg,
      // position: 'top',
      // animated: true,
      duration: 2000
    });
    toast.present();
  }


  register() {

    this.generateotp();
    // this.presentToast('OTP Send to your Mobile No=' + this.otp);
    this.sendMeberSMS();
    this.presentPrompt();

  }






  private submitData() {
    console.log('Customer json in submit');
    console.log(this.user);
    this.user.city = this.user.address.city;
    this.user.login.username = this.user.phone;
    // if (this.user.pan != '' || this.user.gst != '') {
    // if (this.user.gst === '') {
    //   delete this.user.gst;
    // }
    // if (this.user.pan === '') {
    //   delete this.user.pan;
    // }
    this.user.login.password = window.btoa(this.user.login.password);
    console.log('submitData function');
    console.log(this.user);
    const url = this.restService.customerRestURL('add', '');
    this.restService.postFormData(url, this.user).subscribe(
      (response: any) => {
        // Responce data.
        console.log('Status on Post API');
        console.log(response);
        // Now do your stuff here
        // this.userId = response.id;
        localStorage.setItem('id', response.id);
        localStorage.setItem('name', response.name);
        localStorage.setItem('type', response.login.type);
        localStorage.setItem('islogin', 'true');
        // localStorage.setItem('islogin', 'true');
        localStorage.setItem('email', response.email);
        localStorage.setItem('phone', response.phone);
        localStorage.setItem('Address', JSON.stringify(response.address));
        window.scrollTo(0, 0);
        this.presentToast('Loggedin Successful');
        this.route.navigate(['/tabs']);
      },
      error => {
        // Error Message
        this.generatepass();
        this.presentToast('Failed to register');
        console.log('Error in data load.');
      }
    );
    return 0;
    // } else {
    //   Swal.fire(
    //     'Please add PAN no. Or GST no.',
    //      '',
    //      'error'
    //    );
    // }
  }

  generatepass() {
    this.user.login.password = String(Math.floor(100000 + Math.random() * 900000)); // this.generatepassword;
    this.firm.login.password = this.user.login.password;
    this.delivery.login.password = this.user.login.password;
  }

  generateotp() {
    this.otp = String(Math.floor(100000 + Math.random() * 900000)); // this.generatepassword;
  }

  async presentPrompt() {
    const alert = await this.alertController.create({
      header: 'Verify OTP',
      inputs: [
        {
          name: 'OTP',
          placeholder: '_ _ _ _ _ _'
        }
      ],
      buttons: [
        {
          text: 'Resend OTP',
          // role: 'cancel',
          handler: data => {
            // console.log('Cancel clicked');
            this.register();
          }
        },
        {
          text: 'Verify',
          handler: data => {
            if (Number(this.otp) == Number(data.OTP)) {
              // logged in!
              console.log(this.otp);
              console.log(this.userotp);
              this.presentToast('OTP Verified');
              if (this.segment === 'CUSTOMER') {
                this.submitData();
              } else   if (this.segment === 'FIRM') {
                this.submitData1();
              } else   if (this.segment === 'DELIVARY_PERSON') {
                this.submitData2();
              }
            } else {
              // invalid login
              this.presentToast('Failed to Verify');
              return false;
            }
          }
        }
      ]
    });
    await alert.present();
  }


  async segmentChanged(obj) {
    console.log(obj);
    console.log(this.segment);

  }






  // private getStateList() {
  //   // Get Information from JSON REST api
  //   var url = this.restService.stateRestURL('', 'India');
  //   this.restService.getJSONFromURL(url).subscribe(
  //     (response:any) => {
  //       // this.restService.getJSONFromURL(response);
  //       this.statelist = response;
  //       console.log('State data available');
  //     },
  //     error => {
  //       console.log('Error in data load.');
  //     }
  //   );
  // }


  // private onChangeState(obj) {
  //   let stateId = obj.srcElement.value;
  //   // Call city data method
  //   this.getCityList(stateId);
  // }

  //   private getCityList(stateId) {
  //   this.citylist = [];
  //   // Get Information from JSON REST api
  //   var url = this.restService.cityRestURL('', stateId);
  //   console.log(stateId);
  //   this.restService.getJSONFromURL(url).subscribe(
  //     (response:any) => {
  //       this.citylist = response;
  //     },
  //     error => {
  //       console.log('Error in data load.');
  //     }
  //   );
  // }

   getState(obj) {
    // Get Information from JSON REST api

    console.log(obj);

    const url = this.restService.PincodeRestURL('', obj.target.value);
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        // this.restService.getJSONFromURL(response);
        // this.statelist = response;
        this.firm.address.states = response.state_name;
        this.firm.address.city = response.city_name;

        this.delivery.address.city = response.state_name;
        this.delivery.address.states = response.city_name;


        this.user.address.states = response.state_name;
        this.user.address.city = response.city_name;



        console.log('State data available');
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  private getCatlist() {
    // Get Information from JSON REST api
    const url = this.restService.catRestURL('', '');
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.categoryList = response;
        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }


  fileEvent(fileInput: any) {
    // alert('file event begin');
    if (fileInput.target.files[0] != '') {
      this.file = fileInput.target.files[0];
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.urls = event.target.result;
      }
      reader.readAsDataURL(fileInput.target.files[0]);
      console.log('Inside multiple file select');
    }
  }



  fileEvent1(fileInput: any) {
    // alert('file event begin');
    if (fileInput.target.files[0] != '') {
      this.file = fileInput.target.files[0];
      // this.fileName = this.user.category;


      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.urls = event.target.result;
      }
      reader.readAsDataURL(fileInput.target.files[0]);
      console.log('Inside multiple file select');
    }
  }

  fileEvent2(fileInput: any) {
    // alert('file event begin');
    if (fileInput.target.files[0] != '') {
      this.file1 = fileInput.target.files[0];
      // this.fileName = this.user.category;


      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.urls1 = event.target.result;
      }
      reader.readAsDataURL(fileInput.target.files[0]);


      console.log('Inside multiple file select');

    }
    // alert(this.fileName);
    // alert('file event end');
    // preview
  }



  submitData1() {

    // let flg = true;

    //  if (this.firm.pannum != '' || this.firm.gstin != '') {
    this.firm.login.username = this.firm.phone;

    if (this.firm.gstin === '') {
      delete this.firm.gstin;
    }

    if (this.firm.pannum === '') {
      delete this.firm.pannum;
    }

    this.firm.login.password = window.btoa(this.firm.login.password);


    console.log('submiti function');
    var url = this.restService.firmRestURL('add', '');
    console.log(url);
    this.restService.postFormData(url, this.firm).subscribe(
      (response: any) => {
        // Responce data.
        console.log('Status on Post API');
        console.log(response);
        this.firmid = response.id;
        if (this.file) {
          this.uploadfile();
          this.submitdoc();
        }
        window.scrollTo(0, 0);

        localStorage.setItem('id', response.id);
        localStorage.setItem('name', response.name);
        localStorage.setItem('type', response.login.type);
        localStorage.setItem('islogin', 'true');
        localStorage.setItem('islogin', 'true');
        localStorage.setItem('email', response.login.email);
        localStorage.setItem('role', response.login.role);
        localStorage.setItem('firm', response.id);
        localStorage.setItem('category', response.category);
      //  localStorage.setItem('photo', response.logo.docpath);

        this.presentToast('Loggedin Successful');
        this.route.navigate(['/tabs/tab1']);
      },
      error => {
        this.generatepass();
        // Error Message
        // Swal.fire(
        //   error.statusText,
        //   error._body,
        //   'error'
        // );
        this.presentToast('Loggedin Failed');

        console.log('Error in data load.');
        // Doyour stuff here
      }
    );
    return 0;
    // } else {
    // //  alert('errror2');
    // }
  }


  uploadfile() {

    if (this.file) {
      const fileExtension = '.' + this.file.name.split('.').pop();
      const rname = Math.random().toString(36).substring(7) + new Date().getTime();

      let objDoc = new Object();
      this.photo.docName = this.file.name;
      this.photo.docType = 'LOGO';
      this.photo.docpath = this.firmid + '/' + rname + this.file.name;

      var docFormData = new FormData();
      // docFormData.append('doc', this.file, this.fileName);
      docFormData.append('doc', this.file, rname + this.file.name);
      docFormData.append('name', this.firmid);
      var docurl = this.restService.docsRestURL('upload', '');
      console.log(docurl);

      this.restService.uploadFormData(docurl, docFormData).subscribe(
        (response: any) => {
          // Responce data.
          console.log('Status on Upload API');
          console.log(response);
          // Now do your stuff here
          return 1;
        },
        error => {
          // Error Message
          console.log('Error in doc upload .');
          return 0;
          // Do your stuff here
        }
      );
    } else {
      return 0;
    }

  }


  submitdoc() {

    let docs = {
      id: this.firmid,
      logo: this.photo
    };

    console.log('submiti function');
    var url = this.restService.firmRestURL('logoadd', '');
    console.log(url);
    this.restService.postFormData(url, docs).subscribe(
      (response: any) => {
        // Responce data.
        this.firmid = response.id;
        console.log('Status on Post API');
        console.log(response);
      },
      error => {
        // Error Message
        // this.alertify.alert('<b>Failed to add Firm Logo</b><br>' + error.statusText + '<br>'
        //   + error._body);
        console.log('Error in data load.');
        // Doyour stuff here
      }
    );
    return 0;
  }




  private submitData2() {
    console.log('Delivery Pool json in submit');
    console.log(this.user);
    // this.user.city = this.user.address.city;
    this.user.phone = this.user.login.username;
    this.delivery.login.username = this.delivery.phone;
    // if (this.user.pan != '' || this.user.gst != '') {
    // if (this.user.gst === '') {
    //   delete this.user.gst;
    // }
    // if (this.user.pan === '') {
    //   delete this.user.pan;
    // }
    this.delivery.login.password = window.btoa(this.delivery.login.password);
    console.log('submitData function');
    console.log(this.user);
    const url = this.restService.delivertypoolRestURL('add', '');
    this.restService.postFormData(url, this.delivery).subscribe(
      (response: any) => {
        // Responce data.
        console.log('Status on Post API');
        console.log(response);


        this.deliverypoolid = response.id;
        // file upload code start

        if (this.file) {
          this.uploadfile1();
          this.submitdoc1();
        }

        if (this.file1) {
          this.uploadfile2();
          this.submitdoc2();
        }

        // file upload code end


        // Now do your stuff here
        // this.userId = response.id;
        localStorage.setItem('id', response.id);
        localStorage.setItem('name', response.name);
        localStorage.setItem('type', response.login.type);
        localStorage.setItem('islogin', 'true');
        // localStorage.setItem('islogin', 'true');
        localStorage.setItem('email', response.email);
        localStorage.setItem('phone', response.phone);
       // localStorage.setItem('Address', JSON.stringify(response.address));
        window.scrollTo(0, 0);
        this.presentToast('Loggedin Successful');
       // this.route.navigate(['/deliverypools']);
        this.route.navigate(['/deliverypools/deliverypool-home']);
      },
      error => {
        // Error Message
        this.generatepass();
        this.presentToast('Failed to register');
        console.log('Error in data load.');
      }
    );
    return 0;
    // } else {
    //   Swal.fire(
    //     'Please add PAN no. Or GST no.',
    //      '',
    //      'error'
    //    );
    // }
  }


  sendMeberSMS() {
    const message = 'OTP for Local For Vocal App is :'+this.otp;

    let mobile ='0000000000';

    switch (this.segment) {
      case 'CUSTOMER':
        mobile = this.user.phone;
        break;
      case 'FIRM':
        mobile = this.firm.phone;
        break;
      default:
        mobile = this.delivery.phone;
        break;
    }

    const smsdata = {
        toMobile: mobile,
        message: message
    };

    console.log('sending sms');
    console.log(smsdata);
    const url = this.restService.smsRestURL('send', '');

    console.log(url);
    this.restService.postFormData(url, smsdata).subscribe(
      response => {
        // Responce data.
        console.log('Status on Post API');
        console.log(response);
      },
      error => {
        console.log('Error in SMS.');
      }
    );
    return 0;
  }



  uploadfile1() {

    if (this.file) {
      const fileExtension = '.' + this.file.name.split('.').pop();
      const rname = Math.random().toString(36).substring(7) + new Date().getTime();

      let objDoc = new Object();
      this.license.docName = this.file.name;
      this.license.docType = 'LIC';
      this.license.docpath = this.deliverypoolid + '/' + rname + this.file.name;

      var docFormData = new FormData();
      // docFormData.append('doc', this.file, this.fileName);
      docFormData.append('doc', this.file, rname + this.file.name);
      docFormData.append('name', this.deliverypoolid);
      var docurl = this.restService.docsRestURL('upload', '');
      console.log(docurl);

      this.restService.uploadFormData(docurl, docFormData).subscribe(
        (response: any) => {
          // Responce data.
          console.log('Status on Upload API');
          console.log(response);
          // Now do your stuff here
          return 1;
        },
        error => {
          // Error Message
          console.log('Error in doc upload .');
          return 0;
          // Do your stuff here
        }
      );
    } else {
      return 0;
    }

  }


submitdoc1() {

  let docs = {
    id: this.deliverypoolid,
    license: this.license
  };

  console.log('submiti function');
  var url = this.restService.delivertypoolRestURL('photoadd', '');
  console.log(url);
  this.restService.postFormData(url, docs).subscribe(
    (response: any) => {
      // Responce data.
      this.deliverypoolid = response.id;
      console.log('Status on Post API');
      console.log(response);
    },
    error => {
      // Error Message
      // this.alertify.alert('<b>Failed to add Firm Logo</b><br>' + error.statusText + '<br>'
      //   + error._body);
      console.log('Error in data load.');
      // Doyour stuff here
    }
  );
  return 0;
}



uploadfile2() {

  if (this.file1) {
    const fileExtension = '.' + this.file1.name.split('.').pop();
    const rname = Math.random().toString(36).substring(7) + new Date().getTime();

    let objDoc = new Object();
    this.vehiclereg.docName = this.file1.name;
    this.vehiclereg.docType = 'REG_NUM';
    this.vehiclereg.docpath = this.deliverypoolid + '/' + rname + this.file1.name;

    var docFormData = new FormData();
    // docFormData.append('doc', this.file1, this.file1Name);
    docFormData.append('doc', this.file1, rname + this.file1.name);
    docFormData.append('name', this.deliverypoolid);
    var docurl = this.restService.docsRestURL('upload', '');
    console.log(docurl);

    this.restService.uploadFormData(docurl, docFormData).subscribe(
      (response: any) => {
        // Responce data.
        console.log('Status on Upload API');
        console.log(response);
        // Now do your stuff here
        return 1;
      },
      error => {
        // Error Message
        console.log('Error in doc upload .');
        return 0;
        // Do your stuff here
      }
    );
  } else {
    return 0;
  }

}


submitdoc2() {

  let docs = {
    id: this.deliverypoolid,
    vehiclereg: this.vehiclereg
  };

  console.log('submiti function');
  var url = this.restService.delivertypoolRestURL('photoadd', '');
  console.log(url);
  this.restService.postFormData(url, docs).subscribe(
    (response: any) => {
      // Responce data.
      this.deliverypoolid = response.id;
      console.log('Status on Post API');
      console.log(response);
    },
    error => {
      // Error Message
      // this.alertify.alert('<b>Failed to add Firm Logo</b><br>' + error.statusText + '<br>'
      //   + error._body);
      console.log('Error in data load.');
      // Doyour stuff here
    }
  );
  return 0;
}


}
