import { RestService } from './../services/rest.service';
import { CartService } from './../cart.service';
import { Component, OnInit } from '@angular/core';
import { ToastController } from '@ionic/angular';
declare var  RazorpayCheckout: any;
declare var Razorpay: any;


@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage implements OnInit {
  selectedItems = [];
  total = 0;
  deliverycharges = 30;
  grandtotal = 0;

  private transcationid;

  custName = localStorage.getItem('name');
  address = JSON.parse(localStorage.getItem('Address'));


  public expdeliverytime;
  public day;


  // // payment json
  // options: any = {
  //   key: 'rzp_test_BFZPuXGalgBJ1L', // Enter the Key ID generated from the Dashboard
  //   amount: 50000, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
  //   currency: 'INR',
  //   name: 'iNouvelle Ventures Pvt. Ltd.',
  //   description: 'Test Transaction',
  //   image: 'http://inouvelle.com/images/inouvelle_logo.png',
  //   handler: this.submitData.bind(this),
  //   // handler: function (response) {
  //   //   //  alert(response.razorpay_payment_id);
  //   //   // this.submitData(response.razorpay_payment_id);
  //   //   // console.log('response.razorpay_payment_id '+response.razorpay_payment_id);
  //   //   // this.transcationid = response.razorpay_payment_id;
  //   //   // this.submitData(this.transcationid);
  //   // },
  //   prefill: {
  //     name: localStorage.getItem('name'),
  //     email: localStorage.getItem('email'),
  //     contact: localStorage.getItem('phone'), // "9999999999"
  //   },
  //   notes: {
  //     address: 'Razorpay Corporate Office'
  //   },
  //   theme: {
  //     color: '#F37254'
  //   }
  // };


  order = {
    firm: localStorage.getItem('selectedFirm'),
    customer: localStorage.getItem('id'),
    // "invoicenum":"PYS-IN#001",   -- generate and show read only
    //  "invoicedate":"2020-05-28",   ---- if any need of set invoicedate from backend then contac backend team
    // "deliveryaddress":         -- customer address
    //   {"line1":"Flat no. 400",
    //   "line2":"Ram Nagar",
    //   "city":"Pune",
    //   "states":"MAHARASHTRA",
    //   "pincode":"440019",
    //   "country":"India"},
    // "custname":"elsa",
    // "custmobile":"78878787",
    // "custcity":"nagpur",
    qcost: {
      totalitem: 0,
      baseprice: 0,
      gstamt: 0,
      delivery: 0,
      finalamt: 0,
      discountrate: 0,
      discountvalue: 0,
      servicecharge: 0,
      transferamt: 0
    },

    // "comments":"Order data",   -- anything specific realted to order
    status: 'PLACED',      // -- enum PLACED/ACCEPTED/IN_PROCESS / PACKED / DELIVERED
    expdelivery: '2020-05-28',   // how to calculate
    expdeliverytime: '07:00:00', // how to calculate
                 //   firm delivery days : 0 +6

    paymentmode: 'BANK', //  --- always BANK (because we don't have cash on delivery provision)
    favourite:'NO',     //  -- YES/NO default NO.
    //  'deliverypool': '67', // -- if usedeliverypool = YES, assign person for delivery.
        transactionid: '',
        oentry:[]

  };

 oentry = [];

//  {
//   'pname': 'Almond',
//   'rateperunit': '20',
//   'qty': '2',
//   'amount': '80',
//   'gst': '2',
//   'gstamt': '30',
//   'entrytotal': '1'
// }





constructor(private CartService: CartService,
            private restService: RestService,
            public toastController: ToastController) { }

ngOnInit() {
this.recal();

}


recal(){

 // alert('1');
 console.log('cartData');

 let items = [];
 items =this.CartService.getCart(); //  JSON.parse(localStorage.getItem('cartData')); //
// alert('2');
 console.log(items);

 let selected = {};

 for (let obj of items) {
   if (selected[obj.id]) {
     console.log('selected[obj.id].count=' + selected[obj.id].count);
     console.log('obj.quantity=' + obj.quantity);
     selected[obj.id].count = parseFloat(selected[obj.id].count) + parseFloat(obj.quantity);
     console.log('selected[obj.id].count=' + selected[obj.id].count);
     console.log('obj.quantity=' + obj.quantity);
   } else {
     selected[obj.id] = { ...obj, count: obj.quantity };
   }
 }
// alert('3');
 this.selectedItems = Object.keys(selected).map(key => selected[key]);
 console.log('items:', this.selectedItems);
 this.total = this.selectedItems.reduce((a, b) => a + (b.count * b.price), 0);
 this.grandtotal = this.total + this.deliverycharges;
 // this.options.amount = this.grandtotal * 100;
// alert('4');
 this.populateorder();
 this.getDeliverydetails();
}


initPay() {


    // payment json
    let options: any = {
      key: 'rzp_test_BFZPuXGalgBJ1L', // Enter the Key ID generated from the Dashboard
      amount: this.grandtotal * 100, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
      currency: 'INR',
      name: 'iNouvelle Ventures Pvt. Ltd.',
      description: 'Test Transaction',
      image: 'http://inouvelle.com/images/inouvelle_logo.png',
      handler: this.submitData.bind(this),
      // handler: function (response) {
      //   //  alert(response.razorpay_payment_id);
      //   // this.submitData(response.razorpay_payment_id);
      //   // console.log('response.razorpay_payment_id '+response.razorpay_payment_id);
      //   // this.transcationid = response.razorpay_payment_id;
      //   // this.submitData(this.transcationid);
      // },
      prefill: {
        name: localStorage.getItem('name'),
        email: localStorage.getItem('email'),
        contact: localStorage.getItem('phone'), // "9999999999"
      },
      notes: {
        address: 'Razorpay Corporate Office'
      },
      theme: {
        color: '#F37254'
      }
    };


    var rzp1 = new Razorpay(options);
    rzp1.open();
    console.log('works');
    // this.submitData(this.transcationid);
}

payWithRazor() {
  var options = {
    description: 'Credits towards VFL',
    image: 'http://inouvelle.com/images/inouvelle_logo.png',
    currency: 'INR', // your 3 letter currency code
    key: 'rzp_test_BFZPuXGalgBJ1L', // your Key Id from Razorpay dashboard
    amount: this.grandtotal * 100, // Payment amount in smallest denomiation e.g. cents for USD
    name: 'iNouvelle Ventures Pvt. Ltd.',
    prefill: {
      name: localStorage.getItem('name'),
      email: localStorage.getItem('email'),
      contact: localStorage.getItem('phone'), // "9999999999"
    },
    theme: {
      color: '#F37254'
    },
    modal: {
      ondismiss: function () {
        alert('dismissed')
      }
    }
  };



  // var successCallback = (payment_id) => { // <- Here!
  //   alert('payment_id: ' + payment_id);
  //   console.log('logic to add order');
  //   this.transcationid = payment_id;
  //   console.log( 'response.razorpay_payment_id');
  //   console.log( payment_id);
  //   this.order.transactionid = this.transcationid;
  //   this.addOrder();
  // };


                    //   var successCallback = (success) =>{
                    //     alert('payment_id: ' + success.razorpay_payment_id);

                    //     console.log('logic to add order');
                    //     this.transcationid = success.razorpay_payment_id;
                    //     console.log( 'success.razorpay_payment_id');

                    //     this.order.transactionid = this.transcationid;
                    //     this.addOrder();
                    // };

                    //   var cancelCallback = (error) => { // <- Here!
                    //     alert(error.description + ' (Error ' + error.code + ')');
                    //   };





  // this.platform.ready().then(() => {
  //   RazorpayCheckout.open(options, successCallback, cancelCallback);
  // })



  // var successCallback = function (payment_id) {
  //   alert('payment_id: ' + payment_id);

  //   console.log('logic to add order');
  //   this.transcationid = payment_id;
  //   console.log( 'response.razorpay_payment_id');
  //   console.log( payment_id);
  //   this.order.transactionid = this.transcationid;
  //   this.addOrder();
  // };

  // var cancelCallback = function (error) {
  //   alert(error.description + ' (Error ' + error.code + ')');
  // };

//  RazorpayCheckout.open(options, successCallback, cancelCallback);

  var successCallback = (success)=> {
   // alert('payment_id: ' + success.razorpay_payment_id)
    var orderId = success.razorpay_order_id;
    var signature = success.razorpay_signature;
    this.transcationid = orderId;
    this.order.transactionid = this.transcationid;
    this.addOrder();
  }

  var cancelCallback = (error)=>{
    alert(error.description + ' (Error ' + error.code + ')');
  };
  RazorpayCheckout.on('payment.success', successCallback)
  RazorpayCheckout.on('payment.cancel', cancelCallback)
  RazorpayCheckout.open(options);
}

cancel() {
  // goBack code fro cancel button
 // window.history.back();
 location.reload();

}

submitData(response) {
 // alert('payemnt Success');
  console.log('logic to add order');
  this.transcationid = response.razorpay_payment_id;
  console.log( 'response.razorpay_payment_id');
  console.log( response.razorpay_payment_id);
  // alert('calling to add order' + response.razorpay_payment_id);
  // if(this.options.handler){
  // this.populateorder();
  // }
  this.order.transactionid = this.transcationid;
  this.addOrder();



}

public addOrder() {

  alert('order add call');

  console.log('submitData function');
  console.log(this.order);
  const url = this.restService.compactRestURL('addorder', '');
  this.restService.postFormData(url, this.order).subscribe(
    response => {
      // Responce data.
      console.log('Status on Post API');
      console.log(response);
     // Swal('Added', '', 'success');

      // this.router.navigate(['/managecustomer']);
      // window.scrollTo(0, 0);
      this.presentToast('Order Placed');
      localStorage.removeItem('cartData');
      this.cancel();

    },
    error => {
      // Error Message
      // Swal(
      //   error.statusText,
      //   error._body,
      //   'error'
      // );
      console.log('Error in data load.');
      // Doyour stuff here
    }
  );
  return 0;
}

populateorder(){

 // oentry = [];
  console.log('selected items');
  console.log(this.selectedItems);
  this.oentry = [];

  this.order.transactionid = this.transcationid;

  for (let data of this.selectedItems) {
    const obj =  {
        pname: data.name,
        rateperunit: data.price ,
        qty: data.quantity,
        amount: Number(data.price) * Number(data.quantity),
        gst: Number(data.gst),
        gstamt: Number(data.gstamt),
        entrytotal: '1'
      };
    this.oentry.push(JSON.parse(JSON.stringify(obj)));
    console.log('this.oentry');
    console.log(this.oentry);
  }

  this.order.qcost.totalitem = Number(this.selectedItems.length);
  this.order.qcost.baseprice = this.selectedItems.reduce((a, b) => a + (b.count * b.price), 0);
  this.order.qcost.gstamt = this.selectedItems.reduce((a, b) => a + (b.count * b.gstamt), 0);
  this.grandtotal =  this.grandtotal + this.order.qcost.gstamt;
  this.order.qcost.delivery = this.deliverycharges;
  this.order.qcost.finalamt = this.grandtotal;


  this.order.oentry = this.oentry;
  // this.order.expdelivery = this.day;

  console.log('order details');
  console.log(this.order);







      // this.selectedItems = Object.keys(selected).map(key => selected[key])
      // console.log('items:', this.selectedItems);
      // this.total = this.selectedItems.reduce((a, b) => a + (b.count * b.price), 0);
      // this.grandtotal = this.total + this.deliverycharges;
      // this.options.amount = this.grandtotal * 100;




  // qcost: {
  //   totalitem: 0,
  //   baseprice: 0,
  //   gstamt: 0,
  //   delivery: 0,
  //   finalamt: 0,
  //   discountrate: 0,
  //   discountvalue: 0,
  //   servicecharge: 0,
  //   transferamt: 0
  // },

  // {
  //   'pname': 'Almond',
  //   'rateperunit': '20',
  //   'qty': '2',
  //   'amount': '80',
  //   'gst': '2',
  //   'gstamt': '30',
  //   'entrytotal': '1'
  // }



}



getDeliverydetails() {
  // alert('getting list');
  console.log('Getting delivery details');
  const urlstr = localStorage.getItem('selectedFirm');
  const url = this.restService.compactRestURL('deliverydate', urlstr);
  this.restService.getJSONFromURL(url).subscribe(
    (response: any) => {
      this.restService.getJSONFromURL(response);
      console.log(response);
      this.expdeliverytime = response.expdeliverytime;
      this.day = response.day;
      this.order.expdelivery = this.unixTimeConverter(this.day);
    },
    error => {
      console.log('Error in data load.');
    }
  );
}

async presentToast(msg: any) {
  const toast = await this.toastController.create({
    message: msg,
    // position: 'top',
    // animated: true,
    duration: 2000
  });
  toast.present();
}



public unixTimeConverter(ts) {
  let datetime = '';
  const dattime1 = '';
  let dd: string;
  let mm: string;
  let temp: string;
  let temp1: string = '0';


  /******************* */
  // Create a new JavaScript Date object based on the timestamp
  // multiplied by 1000 so that the argument is in milliseconds, not seconds.
  const dtt = new Date(ts * 1000);
  // Hours part from the timestamp
  const hours = dtt.getHours();
  // Minutes part from the timestamp
  const minutes = '0' + dtt.getMinutes();
  // Seconds part from the timestamp
  const seconds = '0' + dtt.getSeconds();

  // Will display time in 10:30:23 format
  const formattedTime = hours + ':' + minutes.substr(-2);
  // alert(formattedTime);
  /*********************************************************** */

  try {
    const dateVal = '/Date(' + ts + ')/';
    const date = new Date(parseFloat(dateVal.substr(6)));

    // for month only
    temp = (date.getMonth() + 1).toString();
    if (temp.length < 2) {
      temp1 = '0';
      temp1 = temp1 + temp;
      // alert(temp);
      mm = temp1;
    } else { mm = (date.getMonth() + 1).toString(); }

    // for date only
    temp = date.getDate().toString();
    if (temp.length < 2) {
      temp1 = '0';
      temp1 = temp1 + temp;

      dd = temp1;
    } else { dd = date.getDate().toString(); }

    //  datetime = date.getFullYear() + "-" + mm + "-" + dd + 'T' + date.toTimeString().slice(0, 5);
    datetime = date.getFullYear() + '-' + mm + '-' + dd;


  } catch (err) {
    console.log('Unable to parse date data in unixTimeConverter');
    datetime = ts;
  }

  // this.tm=formattedTime;
  return datetime;

}

removefromcart(item:any){
console.log('Remove from cart');
console.log(item);

this.CartService.removeProduct(item.id);
this.recal();
}


}
