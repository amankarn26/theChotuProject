import { CartService } from './../cart.service';
import { RestService } from './../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {

  cart = [];
  items = [];

  public docServer = this.restService.docServer;

  sliderConfig = {
    spaceBetween: 10,
    centeredSlides: true,
    slidesPerView: 1.6
  };

  sliderConfig1 = {
    initialSlide: 0,
    slidesPerView: 1,
    autoplay: true
  };

  sliderConfig2 = {
    initialSlide: 0,
    slidesPerView: 1,
    autoplay: true,
    loop: true,
  };

  sliderConfig3 = {
    initialSlide: 1,
    slidesPerView: 2,
    autoplay: true,
    loop: true,
    centeredSlides: true,
    autoplayDisableOnInteraction: false,
    spaceBetween: 20
  };

  sliderConfig4 = {
    initialSlide: 1,
    slidesPerView: 2,
    autoplay: true,
    loop: true,
    centeredSlides: true,
    spaceBetween: 20
  };


  propularprodList = [];
  propularshopList = [];
  offferList = [];

  constructor(private CartService: CartService, private router: Router, private restService: RestService) { }

  ngOnInit() {
    this.cart = this.CartService.getCart();
    // this.items = this.CartService.getProducts(); dummy data form service for slider
    this.getProdtypesData(); // getting data from rest service
    this.getPopularProducts();
    this.getPopularShops();
    this.getOffers();
  }

  addToCart(product) {
    this.CartService.addProduct(product);
  }


  openCart() {
    this.router.navigate(['/cart']);
  }

  private getProdtypesData() {
    // Get Information from JSON REST api
    const url = this.restService.prodtypeRestURL('', '');
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.items = response;
        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }


  private getPopularProducts() {
    // Get Information from JSON REST api
    const url = this.restService.compactRestURL('popularproducts', '');
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.propularprodList = response;
        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  private getPopularShops() {
    // Get Information from JSON REST api
    const url = this.restService.compactRestURL('popularshops', '');
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.propularshopList = response;
        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  private getOffers() {
    // Get Information from JSON REST api
    const url = this.restService.compactRestURL('getoffers', '');
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.offferList = response;
        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

}
