import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [



  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'tab1',
        loadChildren: () => import('../tab1/tab1.module').then(m => m.Tab1PageModule)
      },
      {
        path: 'tab2',
        loadChildren: () => import('../tab2/tab2.module').then(m => m.Tab2PageModule)
      },
      {
        path: 'tab3',
        loadChildren: () => import('../tab3/tab3.module').then(m => m.Tab3PageModule)
      },
      // {
      //   path: ':category',
      //   loadChildren: () => import('../productlist/productlist.module').then( m => m.ProductlistPageModule)
      // },
       {
          path: 'productlist/:category',
          loadChildren: () => import('../productlist/productlist.module').then( m => m.ProductlistPageModule)
        },
      {
        path: 'product-details/:id/:name/:firm',
        loadChildren: () => import('../product-details/product-details.module').then( m => m.ProductDetailsPageModule)
      },
      // {
      //   path: 'cart',
      //   loadChildren: () => import('../cart/cart.module').then( m => m.CartPageModule)
      // },
      {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
      }
    ]
  },
  // {
  //   path: 'productlist',
  //   children: [
  //     {
  //       path: '',
  //       loadChildren: () => import('../productlist/productlist.module').then( m => m.ProductlistPageModule)
  //     },
  //     {
  //       path: ':category',
  //       loadChildren: () => import('../productlist/productlist.module').then( m => m.ProductlistPageModule)
  //     }
  //   ]
  // },
  {
    path: '',
    redirectTo: '/tabs/tab1',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
