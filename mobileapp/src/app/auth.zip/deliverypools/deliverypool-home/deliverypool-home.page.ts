import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deliverypool-home',
  templateUrl: './deliverypool-home.page.html',
  styleUrls: ['./deliverypool-home.page.scss'],
})
export class DeliverypoolHomePage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  showOrders(status: string){
    this.router.navigate(['/deliverypools/deliverypool-orders/' + status]);
  }

}
