import { RestService } from './../services/rest.service';
import { CartService } from './../cart.service';
import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.page.html',
  styleUrls: ['./product-details.page.scss'],
})
export class ProductDetailsPage implements OnInit {
  public category;
  public title;

  public prodid;
  public prodname;

  public docServer = this.restService.docServer;

  cart = [];
  items = [];
  varient;

  product = {
    id: 19174,
    prodtype: '',
    name: '',
    rateunit: "RATEPERKG",
    description: '',
    priority: 1,
    photos: [],
    img: '',
    price: 0,
    quantity: 0,
    status: '',
    gst:0,
    gstamt:0,
    amount:0,
    ratewithgst:0,
    pstock:[]

  };



  // RATEPEEPRODUCT/RATEPERKG/RATEPERDOZEN/RATEPERPKG


  RATEPEEPRODUCT = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  RATEPERKG = [0.100, 0.250, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12];
  RATEPERDOZEN = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  quantity = 0;

  public firm;
  // cartcounter:number;

  constructor(
    private CartService: CartService,
    public route: Router,
    public routprms: ActivatedRoute,
    private restService: RestService) { }

  ngOnInit() {

    this.prodid = this.routprms.snapshot.params['id'];
    this.prodname = this.routprms.snapshot.params['name'];
    this.firm = this.routprms.snapshot.params['firm'];

    // this.cartcounter = this.CartService.getCartCount();

    if (this.route.url === '/tabs/product-details/' + encodeURIComponent(this.prodid) + '/' + encodeURIComponent(this.prodname)
      + '/' + encodeURIComponent(this.firm)) {
      this.title = this.prodname;
      //  this.subtitle = 'Edit Employee  details.';
      // this.flag = true;
      // this.isUpdate = true;
      //  this.updateEmp();
      // this.getRoleList();
      // this.getEmpById();
      // this.getGradeList();
      // this.getAllDept();
      //  this.getAllDept();

      this.cart = this.CartService.getCart();
      //  this.items = this.CartService.getProducts();
      this.getProduct();
    } else {

    }
  }


  addToCart(product) {
    this.CartService.addProduct(JSON.parse(JSON.stringify(product)));
    console.log(product);
    this.cancel();
  }


  openCart() {
    this.route.navigate(['/cart']);
  }

  addQuantity() {
    // if (this.count < 10) {
    //   this.count = this.count + 1;
    //   this.cart.itemQunatity = this.count;
    // }
  }

  removeQuantity() {
    // if (this.count > 1) {
    //   this.count = this.count - 1;
    //   this.cart.itemQunatity = this.count;
    // }
  }


  cancel() {
    // goBack code fro cancel button
    window.history.back();
  }


  getProduct() {
    // alert('getting list');
    console.log('Getting productlist by prodtype and firm');
    const urlstr = 'prod=' + this.prodid + '&firm=' + this.firm;
    const url = this.restService.compactRestURL('proddetailsbyid_firm', urlstr);
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);
        this.items = response;
        this.product.id = response.id;
        this.product.img = this.docServer + '/' + response.image;
        this.product.name = response.name;
        this.product.prodtype = response.prodtype;

        this.product.status = response.status;
        this.product.rateunit = response.rateunit;

        this.product.status = response.status;

        this.product.pstock = response.pstock;

        // this will be get form product stock
        // this.product.price = response.rateperunit;
        // this.product.gst = response.gst;
        // this.product.gstamt = response.gstamt;
        // this.product.amount = response.ratewithgst;
        // this.product.ratewithgst = response.ratewithgst;

        console.log(response);
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  setRatebyvarient(){
    console.log(this.varient);

    const result1 = this.product.pstock.find(x => x.mfg == this.varient);

    if (result1) {
      console.log('searched stock by varient');
      console.log(result1);

      this.product.price = result1.rateperunit;
      this.product.gst = result1.gst;
      this.product.gstamt = result1.gstamt;
      this.product.amount = result1.ratewithgst;
      this.product.ratewithgst = result1.ratewithgst;

    }
  }

}
