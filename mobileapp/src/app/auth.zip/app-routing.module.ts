import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [



  {
    path: '',
    loadChildren: () => import('./index/index.module').then( m => m.IndexPageModule)
  },
  {
    path: '',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'cart',
    loadChildren: () => import('./cart/cart.module').then( m => m.CartPageModule)
  },
  {
    path: '',
    loadChildren: () => import('./vendors/vendors.module').then( m => m.VendorsPageModule)
  },

  {
    path: '',
    loadChildren: () => import('./deliverypools/deliverypools.module').then( m => m.DeliverypoolsPageModule)
  },
  // {
  //   path: 'deliverypools',
  //   loadChildren: () => import('./deliverypools/deliverypools.module').then( m => m.DeliverypoolsPageModule)
  // },
  // {
  //   path: 'productlist/:category',
  //   loadChildren: () => import('./productlist/productlist.module').then( m => m.ProductlistPageModule)
  // }
  // ,
  // {
  //   path: 'product-details/:id/:name/:firm',
  //   loadChildren: () => import('./product-details/product-details.module').then( m => m.ProductDetailsPageModule)
  // },
  // {
  //   path: 'login',
  //   loadChildren: () => import('./auth/login/login.module').then( m => m.LoginPageModule)
  // },
  // {
  //   path: 'register',
  //   loadChildren: () => import('./auth/register/register.module').then( m => m.RegisterPageModule)
  // }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
