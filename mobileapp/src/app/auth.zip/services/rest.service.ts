import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Bug } from './bug';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

// import 'rxjs/add/operator/map';

import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RestService {
  // Base url
  // baseurl = 'http://localhost:3000';
  //  public ip = 'http://localhost';
  public ip = 'http://35.244.54.237';
  public server = this.ip + ':8090/SmartSupplyManager/rest';
  public baseurl = this.ip + ':8090/SmartSupplyManager/rest';

  public docServer = this.ip + ':8090/ssupplydocs';
  public imgServer = this.ip + ':8090/ssupplydocs';


  public firmid = sessionStorage.getItem('firm');

  constructor(private http: HttpClient) { }

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  // Http Headers
  httpOptions1 = {
    headers: new HttpHeaders({
      'Content-Type': 'form-data'
    })
  };

  // Get Data
  public getJSONFromURL(url) {
    /* const headers = new Headers();
     headers.append('Authorization', 'Basic' + btoa('erpadmin' + ':' + 'password'));*/
    //  headers.append('Content-Type', 'application/json, text/plain, */*');

    /* headers.append('Authorization', 'Basic' + btoa('erpadmin' + ':' + 'password'));
      headers.append('Content-Type', 'application/json');*/
    //  headers.append('Accept', 'application/json, text/plain, */*');
    /*   headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
       headers.append('Access-Control-Allow-Credentials', 'true');*/
    /*
'Access-Control-Allow-Origin': 'http://localhost:4200',
        'Access-Control-Allow-Credentials': 'true'
        */
    /*
        var options = new RequestOptions({
          headers: new Headers({
            'Accept': 'application/json',
            'Authorization': 'Basic ZXJwYWRtaW46cGFzc3dvcmQ=',
          })
        });*/
    // let options = new RequestOptions({ headers: headers });
    return this.http.get(url); // .map((response:any) => response.json());


    // GET

  }


  // Post Data
  public postFormData(url, json) {
    const headers = new Headers();
    // headers.append('Authorization', 'Basic ZXJwYWRtaW46cGFzc3dvcmQ=');
    // headers.append('Authorization', 'Basic ' + btoa('erpadmin' + ':' + 'password'));
    //  headers.append('Content-Type', 'application/json');
    // const options = new RequestOptions({ headers: headers }); // Create a request option
    // return this.http.post(url, json, options)
    //   .map(res => {
    //     let newReview = res.json();
    //     console.log('service method: ' + newReview);
    //     return newReview;
    //   });
    // let responsedata = {};

    return this.http.post(url, json, this.httpOptions).pipe(
      map(res => {
        const postresponse = res;
        console.log('service method: ' + postresponse);
        return postresponse;
      })
    );
  }


  public uploadFormData(url, formdata) {
    const headers = new Headers();
    // const headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
    // const options = new RequestOptions({ headers: headers }); // Create a request option


    return this.http.post(url, formdata)
      .pipe(map(res => {
        const postresponse = res;
        console.log('service method: ' + postresponse);
        return postresponse;
      }));
  }



  // Delete Data
  public deleteFormData(url) {
    // let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
    // let options = new RequestOptions({ headers: headers }); // Create a request option

    // return this.http.delete(url, options)
    //   .map((response:any) => response.json());

    // this.httpOptions
    return this.http.delete(url).pipe(
      map((res: Response) => {
        const deleteresponse = res; // .json();
        console.log('service method: ');
        console.log(deleteresponse);
        console.log('end delete response in rest');

        return deleteresponse;
      })
    );

    // return this.http.delete(url, this.httpOptions).pipe(
    //   map((response:any) => response.json())
    // );
  }


  public stateRestURL(restid, countryId) {
    let url = this.server;
    switch (restid) {
      // http://localhost:8090/SmartSupplyManager/rest/common/state?country=India
      default:
        url += '/common/state?country=' + 'India';
        break;
    }
    return url;
  }
  public PincodeRestURL(restid, pincodeId) {
    let url = this.server;
    switch (restid) {
      default:
        url += '/common/pincode?pin=' + pincodeId;
        break;
    }
    return url;
  }
  public cityRestURL(restid, stateId) {
    let url = this.server;
    switch (restid) {

      default:
        //  url += '/cities?state=' + stateId;
        url += '/common/city?state=' + stateId;

        break;
    }
    return url;
  }




  public compactRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'prodlistbytype_firm':
        url += '/compact?' + userId;
        break;

      case 'proddetailsbyid_firm':
        url += '/compact?' + userId;
        break;

      case 'edit':
        url += '/login/update';
        break;
      case 'details':
        url += '/stop/getById/' + userId;
        break;
      case 'delete':
        url += '/stop/delete';
        break;
      case 'deliverydate':
        url += '/firm/delivery/' + userId;
        break;

      case 'addorder':
        url += '/order';
        break;

      case 'updateorder':
        url += '/order/update';
        break;

      case 'ordersbycustomer':
        url += '/order?cust=' + userId;
        break;

      case 'popularproducts':
        url += '/order/popular/product';
        break;

      case 'popularproductsfirm':
        url += '/order/popular/product';
        break;

      case 'popularshops':
        url += '/order/popular';
        break;

      case 'getoffers':
        url += '/common/doc?type=OFFER';
        break;


      case 'ordersbyfirm':
        url += '/order' + userId;
        break;
      case 'ordersbydeliverypool':
        url += '/order' + userId;
        break;

      case 'getproductsbyfirmcat':
        url += '/product' + userId;
        break;
      case 'ordersbydeliverypool':
        url += '/order' + userId;
        break;


      case 'stockadd':
        url += '/product/stock/addM';
        break;

      default:
        url += '/stop';
        break;
    }
    return url;
  }

  public loginRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'login':
        url += '/login';
        break;
      case 'edit':
        url += '/login/update';
        break;
      case 'details':
        url += '/stop/getById/' + userId;
        break;
      case 'delete':
        url += '/stop/delete';
        break;
      default:
        url += '/stop';
        break;
    }
    return url;
  }

  public firmRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/firm';
        break;
      case 'edit':
        url += '/firm/update';
        break;
      case 'details':
        url += '/firm/' + userId;
        // url += '/court/getById/' + userId;
        break;
      case 'delete':
        url += '/firm/' + userId;
        break;
      case 'logoadd':
        url += '/firm/logo';
        break;
      case 'config':
        url += '/system?firm=' + userId;
        break;
      case 'configadd':
        url += '/system/addM';
        break;

      case 'configdelete':
        url += '/system/' + userId;
        break;

      case 'vendorstatistics':
        // http://localhost:8090/SmartSupplyManager/rest/firm/stats?vendor=20
        url += '/firm/stats?vendor=' + userId;
        break;


      // http://localhost:8090/SmartSupplyManager/rest/firm/delivery/20
      // case 'deliverydate':
      //   url += '/firm/delivery/' + userId;
      //   break;
      default:
        url += '/firm';
        break;
    }
    return url;
  }

  // public actcatRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/acctcategory/add';
  //       break;
  //     case 'edit':
  //       url += '/acctcategory/update';
  //       break;
  //     case 'details':
  //       url += '/acctcategory/id/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/category/delete';
  //       break;
  //     default:
  //       url += '/acctcategory';
  //       //url += '/category/getById/' + userId;
  //       break;
  //   }
  //   return url;
  // }
  // public actRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/account/add';
  //       break;
  //     case 'edit':
  //       url += '/account/update';
  //       break;
  //     case 'details':
  //       url += '/account/id/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/account/delete';
  //       break;
  //     default:
  //       url += '/account';
  //       //url += '/category/getById/' + userId;
  //       break;
  //   }
  //   return url;
  // }
  // public accountRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/account';
  //       break;
  //     case 'edit':
  //       url += '/account/update';
  //       break;
  //     case 'details':
  //       url += '/account/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/account' + userId;
  //       break;
  //     case 'accountByid':
  //       url += '/account?firm=' + this.firmid;
  //       break;

  //     default:
  //       url += '/account?firm=' + this.firmid;
  //       break;
  //   }
  //   return url;
  // }


  public catRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/firm/category';
        break;
      case 'edit':
        url += '/firm/category/update';
        break;
      case 'details':
        url += '/firm/category/' + userId;
        break;
      case 'delete':
        url += '/firm/category/' + userId;
        break;
      default:
        url += '/firm/category';
        // url += '/category/getById/' + userId;
        break;
    }
    return url;
  }

  public delivertypoolRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/deliverypool';
        break;
      case 'edit':
        url += '/deliverypool/update';
        break;
      case 'details':
        url += '/deliverypool/' + userId;
        break;
      case 'delete':
        url += '/deliverypool/' + userId;
        break;


        case 'photoadd':
          url += '/deliverypool/doc';
          break;

      default:
        url += '/deliverypool';
        // url += '/category/getById/' + userId;
        break;
    }
    return url;
  }

  // public delivertypoolRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/deliverypool';
  //       break;
  //     case 'edit':
  //       url += '/deliverypool/update';
  //       break;
  //     case 'details':
  //       url += '/deliverypool/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/deliverypool/' + userId;
  //       break;

  //       case 'addarea':
  //       url += '/common/area';
  //       break;

  //       case 'deletearea':
  //         url += '/common/area/'+ userId;
  //         break;


  //       case 'getareabyid':
  //       url += '/common/area/'+userId;
  //       break;

  //       case 'updatearea':
  //         url += '/deliverypool/area/'+userId;
  //         break;

  //         case 'areadelete':
  //           url += '/deliverypool/area/'+userId;
  //           break;


  //     default:
  //       url += '/deliverypool';
  //       // url += '/category/getById/' + userId;
  //       break;
  //   }
  //   return url;
  // }


  public prodtypeRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/product/prodtype';
        // http://localhost:8090/SmartSupplyManager/rest/product/prodtype
        break;
      case 'edit':
        url += '/firm/update';
        break;
      case 'details':
        url += '/firm/getById/' + userId;
        // url += '/court/getById/' + userId;
        break;
      case 'delete':
        url += '/product/prodtype/' + userId;
        break;
      case 'logoadd':
        url += '/firm/logo/add';
        break;
      default:
        url += '/product/prodtype?firm=' + sessionStorage.getItem('firm');;
        break;
    }
    return url;
  }


  // public vouherRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'addPorder':
  //       url += '/porder/history/add';
  //       // http://localhost:8090/IMBAManager/rest/porder/history/add
  //       break;
  //     case 'edit':
  //       url += '/porder/update';
  //       break;
  //     case 'details':
  //       url += '/account/voucher/' + userId;
  //       break;
  //     // http://localhost:8090/IMBAManager/rest/account/voucher/id/214
  //     // case 'vouchers':
  //     //  // url += '/account/voucher/id/' + userId;
  //     //   url += '/voucher/vdetail?voucher=' + userId;
  //     //   break;
  //     // http://localhost:8090/SuppChainManager/rest/voucher/vdetail?voucher=19599
  //     case 'pinwarddetails':
  //       url += '/voucher/pdetail';
  //       break;
  //     case 'delete':
  //       url += '/voucher/' + userId;
  //       break;

  //     case 'addvoucher':
  //       url += '/account/voucher';
  //       break;


  //     case 'supplierByid':
  //       url += '/porder?firm=' + userId;
  //       break;
  //     default:
  //       url += '/account/voucher?firm=' + sessionStorage.getItem('firm');
  //       // http://localhost:8090/IMBAManager/rest/account/voucher?firm=7
  //       break;
  //   }
  //   return url;
  // }

  public productRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/product';
        break;
      case 'edit':
        url += '/product/update';
        break;
      case 'details':
        url += '/product/' + userId;
        break;
      case 'delete':
        url += '/product/' + userId;
        break;
      case 'MPdelete':
        url += '/product/photos/delete';
        break;
      case 'productByid':
        // url += '/prescription?firm=' + userId;
        url += '/product?firm=' + userId;
        break;
      case 'import':
        // url += '/prescription?firm=' + userId;
        url += '/product/import';
        break;
      case 'docarray':
        url += '/product/photos/add ';
        break;

      ///product/prodtype/sale?prodtype=BIKE&forsale=YES&firm=1

      case 'prodbyprodtype':
        url += '/product/prodtype/sale' + userId;;
        break;


      default:
        url += '/product?firm=' + sessionStorage.getItem('firm');
        //  url += '/product?firm=20';
        break;
    }
    return url;
  }

  public prodpropRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/product/prodprop';
        // http://localhost:8090/SmartSupplyManager/rest/product/prodtype
        break;
      case 'edit':
        url += '/firm/update';
        break;
      case 'details':
        url += '/product/prodprop/' + userId;
        // url += '/court/getById/' + userId;
        break;
      case 'delete':
        url += '/product/prodprop/' + userId;
        break;
      case 'logoadd':
        url += '/firm/logo/add';
        break;
      default:
        // http://localhost:8090/SmartSupplyManager/rest/product/prodprop?product=29


        url += '/product/prodprop?product=' + userId;
        break;
    }
    return url;
  }


  public docsRestURL(restid, type) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/doc';
        break;
      case 'productphotoadd':
        url += '/product/photos ';
        break;
      case 'photoadd':
        url += '/employee/photo';
        break;
      case 'edit':
        url += '/doc/update';
        break;
      case 'delete':
        url += '/doc/delete';
        break;
      case 'upload':
        url += '/common/doc/upload';
        break;
      case 'details':
        url += '/doc/getId/' + type;
        break;
      default:
        url += '/doc?type=' + type;
        break;
    }
    return url;
  }


  // public prodpropvalueRestURL(restid, userId) {
  //   let url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/product/pvalue/update';
  //       // http://localhost:8090/SmartSupplyManager/rest/product/prodtype
  //       break;
  //     case 'edit':
  //       url += '/firm/update';
  //       break;
  //     case 'details':
  //       url += '/firm/getById/' + userId;
  //       // url += '/court/getById/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/product/pvalue/delete';
  //       break;
  //     case 'logoadd':
  //       url += '/firm/logo/add';
  //       break;
  //     default:
  //       // http://localhost:8090/SmartSupplyManager/rest/product/prodprop?product=29


  //       url += '/product/prodprop?product=' + userId;
  //       break;
  //   }
  //   return url;
  // }

  // public productstockRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/product/stock/add';
  //       break;
  //     case 'addm':
  //       url += '/product/stock/addM';
  //       break;
  //     case 'edit':
  //       url += '/product/update';
  //       break;
  //     case 'details':
  //       url += '/product/stock/' + userId;
  //       break;
  //     case 'lastlotno':
  //       //    url += '/product/last/lotno?prodcode=' + userId + '&firm=' + sessionStorage.getItem('firm');
  //       url += '/product/newlot/no?product=' + userId;

  //       break;
  //     case 'delete':
  //       url += '/product/stock/delete';
  //       break;
  //     case 'MPdelete':
  //       url += '/product/photos/delete';
  //       break;
  //     case 'available':
  //       url += '/product/stock/check?' + userId;
  //       break;
  //     case 'rate':
  //       url += '/product/rate?' + userId;
  //       //  http://localhost:8090/SuppChainManager/rest/product/rate?prodcode="cap2"&ratelabel=Silver&quantity=100&ptype=SELLING
  //       break;
  //     case 'productByid':
  //       // url += '/prescription?firm=' + userId;
  //       url += '/product?firm=' + userId;
  //       break;
  //     case 'byprodcode':

  //       url += '/product/stock?prodcode=' + userId;
  //       // http://localhost:8090/SuppChainManager/rest/product/stock/get?prodcode=abc12345
  //       // http://localhost:8090/SuppChainManager/rest/product/stock?prodcode=4545
  //       break;
  //     case 'byprodid':
  //       url += '/product/stock?product=' + userId;
  //       break;

  //     // http://localhost:8090/SmartSupplyManager/rest/product/stock?product=102&color=Red
  //     case 'byprodidcolor':
  //       url += '/product/stock?product=' + userId;
  //       break;

  //     case 'byprodstatus':
  //       url += '/product/stock/status?product=' + userId;
  //       break;

  //     case 'bystatprodcode':
  //       url += '/stationery/stock?prodcode=' + userId;
  //       break;
  //     // case 'bystatprodcode':
  //     // console.log(userId);
  //     //    url += '/stationery/stock?prodcode=' + userId;
  //     case 'photoadd':
  //       url += '/product/stock/barcode/add ';
  //       break;
  //     case 'docarray':
  //       url += '/product/photos/add ';
  //       break;

  //     case 'prodstockk':
  //       url += '/product/stock?' + userId;
  //       break;


  //     case 'quantityprod':
  //       url += '/product/stock?' + userId;
  //       break;

  //     case 'quantityspare':  // getting product stock by product id and qty
  //       // http://localhost:8090/SmartSupplyManager/rest/product/stock/status?product=19157&status=AVAILABLE
  //       url += '/product/stock/status?' + userId;
  //       break;

  //     case 'prodstockbyprodid':
  //       url += '/product/stock?product=' + userId;
  //       // http://localhost:8090/SmartSupplyManager/rest/product/stock?product=29
  //       break;

  //     default:
  //       // url += '/product?firm=' + sessionStorage.getItem('firm');
  //       url += '/product/stock';
  //       break;
  //   }
  //   return url;
  // }


  public quoteRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/quote';
        break;


      case 'details':
        url += '/quote/' + userId;
        break;

      case 'quotenumber':
        url += '/quote/newquote/no?etype=' + userId + '&firm=' + sessionStorage.getItem('firm');
        break;

      case 'qinvoicenumber':
        url += '/quote/newinvoice/no?firm=' + sessionStorage.getItem('firm');
        break;

      case 'qsentrybyquoteid':
        url += '/quote/entry?quote=' + userId;;
        break;

      default:
        url += '/quote?firm=' + sessionStorage.getItem('firm');
        break;
    }
    return url;
  }


  public customerRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/customer';
        break;
      case 'edit':
        url += '/customer/update';
        break;
      case 'details':
        url += '/customer/' + userId;
        break;

      case 'detailsbycustname':
        url += '/customer/Name/' + userId;
        break;


      case 'delete':
        url += '/customer/delete';
        break;

      case 'docarray':
        url += '/customer/doc/add';
        // http://localhost:8090/SmartSupplyManager/rest/customer/doc/add

        break;


      case 'cbyrm':
        url += '/customer/marketing?relationshipmgr=' + userId;
        break;

      case 'assignrms':
        url += '/crm/assignrm/cust?firm=' + this.firmid;
        break;

      case 'unassignrms':
        url += '/crm/unassignrm/cust?firm=' + this.firmid;
        break;


      default:
        //  url += '/customer?firm=' + 20;
        url += '/customer';
        //   url += '/customer?firm=' + sessionStorage.getItem('firm');

        break;
    }
    return url;
  }


  // public level2detailRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/customer/level2';
  //       break;

  //     case 'edit':
  //       url += '/customer/level2/update';
  //       break;





  //     case 'travelupdate':
  //       url += '/customer/travel/add';
  //       break;

  //     case 'deletetravel':
  //       url += '/customer/travel/delete';
  //       break;




  //     case 'details':
  //       url += '/customer/level2/custid?custid=' + userId;
  //       break;





  //     case 'delete':
  //       url += '/customer/level2/delete';
  //       break;
  //     case 'prefred':
  //       url += '/customer/preftravel?custid=' + userId;
  //       break;
  //     // case 'supplierByid':
  //     //   url += '/level2detail?firm=' + userId;
  //     //   break;

  //     // case 'city':
  //     //   url += '/level2detail?city=' + userId;
  //     //   break;

  //     case 'detailsbycustomer':
  //       url += '/customer/level2/rid/' + userId;
  //       // http://localhost:8090/SuppChainManager/rest/customer/level2/rid/38444  detailsbycustomer
  //       break;

  //     default:
  //       url += '/customer/level2';
  //       break;
  //   }
  //   return url;
  // }


  // public rlabelRestURL(restid, userId) {
  //   let url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/rlabel';
  //       break;
  //     case 'edit':
  //       url += '/rlabel/update';
  //       break;
  //     case 'details':
  //       url += '/rlabel/' + userId;
  //       break;

  //     case 'delete':
  //       url += '/rlabel/'+ userId;
  //       break;
  //     default:
  //       url += '/rlabel?firm=' + sessionStorage.getItem('firm');
  //       break;
  //   }

  //   return url;
  // }

  // public vendorRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/vendor';
  //       break;
  //     case 'edit':
  //       url += '/vendor/update';
  //       break;
  //     case 'details':
  //       url += '/vendor/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/vendor/'+ userId;
  //       break;
  //     case 'supplierByid':
  //       url += '/vendor?firm=' + userId;
  //       break;
  //     case 'type':
  //       url += '/vendor?category=' + userId+'&firm='+this.firmid;
  //       break;
  //     case 'default':
  //       url += '/vendor/default?category=' + userId;
  //       break;
  //     case 'ttype':
  //       url += '/vendor/type?type=' + userId ;

  //   //    url += '/vendor/type?type=' + userId +'&firm='+this.firmid;
  //        break;
  //     default:
  //       url += '/vendor?firm='+this.firmid;
  //       break;
  //   }
  //   return url;
  // }

  // public empRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/employee';
  //       break;
  //     case 'edit':
  //       url += '/employee/update';
  //       break;
  //     case 'details':
  //       url += '/employee/' + userId;
  //       break;

  //     case 'delete':
  //       url += '/employee/' + userId;
  //       break;

  //     case 'photoadd':
  //       url += '/employee/photo';
  //       break;

  //     case 'dependantadd':
  //       url += '/employee/dependant/add';
  //       break;
  //     case 'dependant':
  //       url += '/employee/dependant/' + userId;
  //       break;
  //     case 'attend':
  //       url += '/employee/attend/add';
  //       break;
  //     case 'details_attend':
  //       url += '/employee/attend/' + userId;
  //       break;
  //     case 'account':
  //       url += '/employee/account/add';
  //       break;
  //     case 'accountUpdate':
  //       url += '/employee/account/update';
  //       break;
  //     case 'details_account':
  //       url += '/employee/account/' + userId;
  //       break;

  //     case 'empbyrole':
  //       url += '/employee?role=' + userId + '&firm=' + this.firmid;
  //       break;

  //     default:
  //       url += '/employee?firm=' + sessionStorage.getItem('firm');
  //       //     url += '/customer?firm=' + sessionStorage.getItem('firm');

  //       break;
  //   }
  //   return url;
  // }




  // public insurerRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/insurer';
  //       break;
  //     case 'edit':
  //       url += '/insurer/update';
  //       break;
  //     case 'details':
  //       url += '/insurer/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/insurer/' + userId;
  //       break;
  //     case 'insurerByid':
  //       url += '/insurer?firm=' + userId;
  //       break;
  //     default:
  //       url += '/insurer?firm=' + sessionStorage.getItem('firm');
  //       //    url += '/insurer?firm=' + 20;
  //       break;
  //   }
  //   return url;
  // }
  // public supplierRestURL(restid, userId) {
  //   var url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/supplier';
  //       break;
  //     case 'edit':
  //       url += '/supplier/update';
  //       break;
  //     case 'details':
  //       url += '/supplier/getById/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/supplier/' + userId;
  //       break;
  //     case 'supplierByid':
  //       url += '/supplier?firm=' + userId;
  //       break;
  //     default:
  //       url += '/supplier?firm=' + sessionStorage.getItem('firm');
  //       break;
  //   }
  //   return url;
  // }




  public userRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/user/add';
        break;
      case 'signup':
        url += '/user/register';
        break;
      case 'login':
        url += '/login';
        break;
      case 'edit':
        url += '/user/update';
        break;
      case 'details':
        url += '/user/get/' + userId;
        break;
      case 'delete':
        url += '/user/delete';
        break;
      case 'count':
        url += '/user/count';
        break;
      default:
        url += '/user';
        break;
    }
    return url;
  }


  public mailRestURL(restid, uid) {
    var url = this.server;
    switch (restid) {
      case 'otp':
        url += '/mail/otp';
        break;
      case 'send':
        url += '/mail/send';
        break;
      case 'groupmail':
        url += '/mail/groupmail';
        break;
      case 'sendPDF':
        url += '/mail/sendPDF';
        break;

      // /rest/mail/sendPDF
      default:
        url += '/mail';
        break;
    }
    return url;
  }
  public MailRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/mail/config';
        break;
      case 'send':
        url += '/mail/send';
        break;
      case 'details':
        url += '/mail/config';
        break;
      case 'group':
        url += '/mail/groupmail';
        break;
      default:
        url += '/category';
        //url += '/category/getById/' + userId;
        break;
    }
    return url;
  }

  // public packingRestURL(restid, userId) {
  //   let url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/packing';
  //       break;
  //     case 'edit':
  //       url += '/product/update';
  //       break;
  //     case 'details':
  //       url += '/packing/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/packing/' + userId;
  //       break;
  //     case 'newpackageno':
  //       url += '/packing/newpkgno?firm=' + userId;
  //       break;

  //     case 'getallpackingbyemp': // get all packing by employee id , packing incharge
  //       url += '/packing?emp=' + userId;
  //       break;

  //     // http://localhost:8090/SmartSupplyManager/rest/packentry/newpkgno?firm=1

  //     default:
  //       url += '/packing?firm=' + sessionStorage.getItem('firm');
  //       //  url += '/product?firm=20';
  //       break;
  //   }
  //   return url;
  // }


  // public dispatchRestURL(restid, userId) {
  //   let url = this.server;
  //   switch (restid) {
  //     case 'add':
  //       url += '/packing';
  //       break;
  //     case 'edit':
  //       url += '/product/update';
  //       break;
  //     case 'details':
  //       url += '/packing/' + userId;
  //       break;
  //     case 'delete':
  //       url += '/product/' + userId;
  //       break;
  //     case 'newdispatchno':
  //       url += '/dispatch/newdispatchno?firm=' + userId;
  //       break; // http://localhost:8090/SmartSupplyManager/rest/dispatch/newdispatchno?firm=1

  //     case 'getallpackingbyemp': // get all packing by employee id , packing incharge
  //       url += '/packing?emp=' + userId;
  //       break;

  //     // http://localhost:8090/SmartSupplyManager/rest/packentry/newpkgno?firm=1

  //     default:
  //       url += '/packing?firm=' + sessionStorage.getItem('firm');
  //       //  url += '/product?firm=20';
  //       break;
  //   }
  //   return url;
  // }



  public returnchallanRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/returnchallan';
        break;
      case 'edit':
        url += '/returnchallan/update';
        break;
      case 'details':
        url += '/returnchallan/' + userId;
        // http://localhost:8090/IMBAManager/rest/returnchallan/getById/39
        break;
      case 'delete':
        url += '/returnchallan/' + userId;
        break;
      case 'returnchallanByid':
        url += '/returnchallan?firm=' + userId;
        break;
      default:
        url += '/returnchallan?firm=' + sessionStorage.getItem('firm');
        break;
    }
    return url;
  }

  public lastlotRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      // http://localhost:8090/SmartSupplyManager/rest/product/newlot/no?product=40
      case 'product':
        url += '/product/newlot/no?product=' + userId;
        break;
      case 'sparepart':
        url += '/sparepart/newlot/no?sparepart=' + userId;
        break;
      case 'porder':
        url += '/porder/neworder/no?firm=' + sessionStorage.getItem('firm');
        // http://localhost:8090/SmartSupplyManager/rest/porder/neworder/no?firm=7
        break;
      case 'voucher':
        url += '/account/newvoucher/no?firm=' + sessionStorage.getItem('firm');
        // http://localhost:8090/SmartSupplyManager/rest/account/newvoucher/no?firm=7
        break;
      case 'booking':
        url += '/booking/newbooking/no?firm=' + sessionStorage.getItem('firm') + '&etype=' + userId;
        //   http://localhost:8090/SmartSupplyManager/rest/booking/newbooking/no?firm=7
        break;


      case 'invoice':
        url += '/servicing/newinvoice/num?firm=' + sessionStorage.getItem('firm');
        // http://localhost:8090/SmartSupplyManager/rest/sale/newinvoice/num?firm=7
        break;

      case 'challan':
        url += '/returnchallan/newchallan/num?firm=' + sessionStorage.getItem('firm');
        // http://localhost:8090/SmartSupplyManager/rest/returnchallan/newchallan/num?firm=5
        break;


      case 'selling':
        url += '/booking/newinvoice/no?firm=' + sessionStorage.getItem('firm'); // '&etype='+userId;
        // http://localhost:8090/SmartSupplyManager/rest/sale/newinvoice/num?firm=7
        break;
      //http://localhost:8090/SmartSupplyManager/rest/booking/newinvoice/no?firm=5
      case 'delete':
        url += '/customer/delete';
        break;
      case 'supplierByid':
        url += '/customer?firm=' + userId;
        break;
      case 'newinvoiceno':
        url += '/account/newinvoice/num?firm=' + userId;
        break;
      // http://localhost:8090/SmartSupplyManager/rest/insurance/newinvoice/num?firm=11
      case 'newvoucherno':
        url += '/account/newvoucher/no?firm=' + userId;
        break;
      // http://localhost:8090/SmartSupplyManager/rest/account/newvoucher/no?firm=7
      default:
        url += '/customer?firm=' + sessionStorage.getItem('firm');
        break;
    }
    return url;
  }




  public roleRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/common/role/add';
        break;
      case 'edit':
        url += '/common/role/update';
        break;
      case 'details':
        url += '/common/role/get?name=' + userId;
        break;

      case 'removeimage':
        url += '/common//file/delete';
        break;
      //   http://localhost:8090/ERPManager/rest/common/file/delete
      case 'delete':
        url += '/common/role/delete';
        break;
      case 'validtill':
        url += '/common/futuredate?numdays=' + userId;
        //  http://localhost:8090/PPressManager/rest/common/date?numdays=4
        //   // http://localhost:8090/SuppChainManager/rest/common/futuredate?numdays=7
        break;
      default:
        url += '/common/role';
        break;
    }
    return url;
  }


  public bulkRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {

      case 'RatelabelAdd':
        url += '/customer/bulk/ratelabel';
        break;

      case 'MaxQuoteAdd':
        url += '/customer/bulk/maxquote';
        break;

      case 'RMAdd':
        url += '/customer/bulk/rm';
        break;

      default:
        url += '/employee/lbal';
        break;
    }
    return url;
  }
  public unixTimeConverterDate(ts) {
    let datetime = '';
    const dattime1 = '';
    let dd: string;
    let mm: string;
    let temp: string;
    let temp1: string = '0';



    // Create a new JavaScript Date object based on the timestamp
    // multiplied by 1000 so that the argument is in milliseconds, not seconds.
    const dtt = new Date(ts * 1000);
    // Hours part from the timestamp
    const hours = dtt.getHours();
    // Minutes part from the timestamp
    const minutes = '0' + dtt.getMinutes();
    // Seconds part from the timestamp
    const seconds = '0' + dtt.getSeconds();

    // Will display time in 10:30:23 format
    const formattedTime = hours + ':' + minutes.substr(-2);
    // alert(formattedTime);


    try {
      const dateVal = '/Date(' + ts + ')/';
      const date = new Date(parseFloat(dateVal.substr(6)));

      // for month only
      temp = (date.getMonth() + 1).toString();
      if (temp.length < 2) {
        temp1 = '0';
        temp1 = temp1 + temp;
        // alert(temp);
        mm = temp1;
      } else { mm = (date.getMonth() + 1).toString(); }

      // for date only
      temp = date.getDate().toString();
      if (temp.length < 2) {
        temp1 = '0';
        temp1 = temp1 + temp;

        dd = temp1;
      } else { dd = date.getDate().toString(); }

      //  datetime = date.getFullYear() + "-" + mm + "-" + dd + 'T' + date.toTimeString().slice(0, 5);
      datetime = date.getFullYear() + '-' + mm + '-' + dd;


    } catch (err) {
      console.log('Unable to parse date data in unixTimeConverter');
      datetime = ts;
    }

    // this.tm=formattedTime;
    return datetime;

  }


  public RetailerRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/retailer/add';
        break;
      case 'edit':
        url += '/retailer/update';
        break;
      case 'details':
        url += '/retailer/id/' + userId;
        break;
      case 'delete':
        url += '/retailer/delete';
        break;
      case 'newclient':
        url += '/crm/marketing?status=' + userId;
        break;
      case 'city':
        // http://localhost:8090/IMBAManager/rest/customer?city=nagpur
        url += '/customer?city=' + userId + '&firm=' + sessionStorage.getItem('firm');
        break;
      case 'deleteAddress':
        url += '/retailer/address/delete';
        break;
      case 'deleteRemarks':
        url += '/retailer/remark/delete';
        break;
      case 'addressadd':
        url += '/retailer/address/add';
        break;
      case 'remarkadd':
        url += '/retailer/remark/add';
        break;
      case 'lastusedadd':
        url += '/retailer/lastused?retailer=' + userId;
        break;
      case 'payment':
        url += '/retailer/payment?retailer=' + userId;
        // http://localhost:8090/SuppChainManager/rest/retailer/payment?retailer=19559
        break;
      case 'retailerbystatus':
        url += '/retailer?status=' + userId;
        // http://localhost:8090/SuppChainManager/rest/retailer/payment?retailer=19559
        break;
      //http://localhost:8090/SuppChainManager/rest/retailer?status=REGISTERED

      // http://localhost:8090/SuppChainManager/rest/retailer/lastused?retailer=19559
      case 'rmcust':
        url += '/retailer?rmid=' + userId;
        // Get Retailer By RM
        // http://localhost:8090/SuppChainManager/rest/retailer?rmid=21
        break;
      default:
        url += '/retailer';
        break;
    }
    return url;
  }

  public shopRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/wholesaler/shop/add';
        break;
      case 'edit':
        url += '/wholesaler/shop/update';
        break;
      case 'details':
        url += '/wholesaler/shop/id/' + userId;
        break;
      case 'delete':
        url += '/wholesaler/shop/delete';
        break;
      case 'supplierByid':
        url += '/wholesaler/shop?firm=' + userId;
        break;
      default:
        url += '/wholesaler/shop';
        break;
    }
    return url;
  }

  public crmRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {

      //http://localhost:8090/PPressManager/rest/crm/call/add
      case 'add':
        url += '/crm/call';
        break;
      case 'edit':
        url += '/crm/call/update';
        break;
      case 'details':
        url += '/crm/call/' + userId;
        break;
      case 'delete':
        url += '/crm/call/' + userId;
        break;
      case 'orderdetails':
        url += '/crm/quote?callto=' + userId;
        break;
      //http://localhost:8090/PPressManager/rest/crm/call/last?cust=1451
      case 'lastcall':
        url += '/crm/call/last?cust=' + userId;
        break;

      case 'speechall':
        url += '/crm/speech?firm=' + this.firmid;
        break;


      case 'speechbyid':
        url += '/crm/speech/' + userId;
        break;

      case 'callblockbyid':
        url += '/crm/block/' + userId;
        break;

      //http://localhost:8090/PPressManager/rest/crm/block/add
      case 'addblockcall':
        url += '/crm/block';
        break;

      case 'updateblockcall':
        url += '/crm/block/update';
        break;


      case 'addspeech':
        url += '/crm/speech/add';
        break;

      case 'deletespeech':
        url += '/crm/speech/' + userId;
        break;

      case 'deletecallblock':
        url += '/crm/block/' + userId;
        break;
      //http://localhost:8090/PPressManager/rest/crm/block

      case 'allblockreq':
        url += '/crm/block';
        break;

      case 'deleteblockreqbyid':
        url += '/crm/block/' + userId;
        break;


      case 'empsaledata':
        url += '/crm/stats?emp=' + userId;
        break;


      case 'empcalldata':
        url += '/crm/call/by?emp=' + userId;
        break;

      case 'calldataall':
        url += '/crm/call/details?emp=' + userId;
        break;



      case 'emptarsaledata':
        url += '/crm/target/stats?emp=' + userId;
        break;


      case 'addtargetcall':
        url += '/crm/target';
        break;

      case 'deletetargetcall':
        url += '/crm/target/' + userId;
        break;


      case 'calltdelete':
        url += '/crm/ctarget/' + userId;
        break;


      case 'targetcallall':
        url += '/crm/target';
        break;

      case 'targetcallbyid':
        url += '/crm/target/' + userId;
        break;

      case 'addreferancecall':
        url += '/crm/reference';
        break;

      case 'referancecallall':
        url += '/crm/reference?firm=' + this.firmid;
        break;


      case 'referancecallbyid':
        url += '/crm/reference/' + userId;
        break;

      case 'allottedclientsstats':
        url += '/crm/all/cust?emp=' + userId;
        break;

      case 'newallottedclientsstats':
        url += '/crm/new/cust?emp=' + userId;
        break;

      case 'followupstats':
        url += '/crm/today/followup?emp=' + userId;
        break;


      case 'regularclientdata':
        url += '/crm/stats/regular?emp=' + userId;
        break;


      case 'irregularclientdata':
        url += '/crm/stats/irregular?emp=' + userId;
        break;

      case 'paymentrecoverydata':
        url += '/crm/stats/payment?emp=' + userId;
        break;


      case 'coldcalldata':
        url += '/crm/coldcall?firm=' + this.firmid;
        break;

      case 'referencecalldata':
        url += '/crm/reference?firm=' + this.firmid;
        break;

      case 'referencecalldelete':
        url += '/crm/reference/' + userId;
        break;

      case 'calldetailsbyemp':
        url += '/crm/call/emp?emp=' + userId;
        break;

      case 'databydates':
        url += '/crm/call/bydate?' + userId;
        break;

      case 'productstatsdonut':
        url += '/crm/doughnut/product?customer=' + userId;
        break;

      case 'papertypestatsdonut':
        url += '/crm/doughnut/paper?customer=' + userId;
        break;

      default:
        url += '/crm/call';
        break;
    }
    return url;
  }

  public campaignRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/crm/campaign';
        break;
      case 'edit':
        url += '/crm/campaign/update';
        break;
      case 'details':
        url += '/crm/campaign/' + userId;
        break;
      case 'delete':
        url += '/crm/campaign/' + userId;
        break;
      default:
        url += '/crm/campaign?firm=' + this.firmid;
        break;
    }
    return url;
  }

  public crmstatsRestURL(restid, userid) {
    let url = this.server;
    switch (restid) {

      ///crm/quotation/monthly?customer=1447&product=7614
      case 'statsbycusprod':
        url += '/crm/quotation/monthly?' + userid;
        break;

      default:
        url += '/stats/applicant';
        break;
    }
    return url;
  }





  public bookRestURL(restid, userId) {
    var url = this.server;
    switch (restid) {
      case 'add':
        url += '/quote';
        break;

      case 'details':
        url += '/quote/' + userId;
        break;

      case 'quotenumber':
        url += '/quote/newquote/no?etype=' + userId + '&firm=' + sessionStorage.getItem('firm');
        break;

      case 'qinvoicenumber':
        url += '/quote/newinvoice/no?firm=' + sessionStorage.getItem('firm');
        break;

      case 'qsentrybyquoteid':
        url += '/quote/entry?quote=' + userId;;
        break;

      // previous
      //   case 'convert':
      //     url += '/booking/convert';
      //     break;

      // case 'edit':
      //   url += '/booking/update';
      //   break;
      //   // http://localhost:8090/IMBAManager/rest/booking/details?booking

      // case 'delete':
      //   url += '/booking/cancel';
      //   // http://localhost:8090/IMBAManager/rest/booking/cancel
      //   break;
      // case 'bookingByid':
      //   // url += '/booking?firm=' + userId;
      //   url += '/booking?firm=' + userId;
      //   break;
      // case 'history':
      //     url += '/booking/history/add';
      //     break;
      default:
        url += '/quote?firm=' + sessionStorage.getItem('firm');
        break;
    }
    return url;
  }





  public categoryRestURL(restid, userId) {
    let url = this.server;
    switch (restid) {
      case 'add':
        url += '/firm/category/prodtype';
        // http://localhost:8090/SmartSupplyManager/rest/product/prodtype
        break;
      case 'edit':
        url += '/firm/category';
        break;
      case 'details':
        url += '/firm/category/' + userId;
        // url += '/court/getById/' + userId;
        break;
      case 'delete':
        url += '/firm/category/' + userId;
        break;
      case 'logoadd':
        url += '/firm/logo/add';
        break;
      default:
        url += '/firm/category';
        break;
    }
    return url;
  }


  public smsRestURL(restid, uid) {
    var url = this.server;
    switch (restid) {
      case 'send':
        url += '/sms/send';
        break;
      case 'groupmail':
        url += '/mail/groupmail';
        break;
      default:
        url += '/mail';
        break;
    }
    return url;
  }







}
