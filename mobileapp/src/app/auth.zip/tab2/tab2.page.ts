import { RestService } from './../services/rest.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit{



  orders: any[] = [];

  orderItems: any;

  custName = localStorage.getItem('name');
  address = JSON.parse(localStorage.getItem('Address'));


  public docServer = this.restService.docServer;

  constructor(private router: Router,  private restService: RestService, public toastController: ToastController) {
   this.getOrders();
  }

  detailFlag = false;

  ngOnInit(): void {
    // Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    // Add 'implements OnInit' to the class.
  }


  isOrders(): boolean {
    return this.orders.length == 0 ? false : true;
  }


   getOrders() {
    // Get Information from JSON REST api
    const url = this.restService.compactRestURL('ordersbycustomer', localStorage.getItem('id'));
    this.restService.getJSONFromURL(url).subscribe(
      (response: any) => {
        this.restService.getJSONFromURL(response);


        this.orders = response;
        // return response;
      },
      error => {
        console.log('Error in data load.');
      }
    );
  }

  ordersDetails(index:any, id:any) {
    console.log('index'+index);
    console.log('id'+id);
    this.detailFlag = true;

    this.orderItems = this.orders[index];


  }

  showorderlist(){
    this.detailFlag = false;
  }



  ionViewWillEnter() {
    this.getOrders();
    this.detailFlag = false;
    console.log('ionViewWillEnter ');  // called on first time
  }

    cancel(){
      this.detailFlag = false;
    }


    like(like: string, id:any){


        let order =   {
        id: id,
        favourite: like
        };


        console.log('update function');
        console.log(order);
        const url = this.restService.compactRestURL('updateorder', '');
        this.restService.postFormData(url, order).subscribe(
          response => {
            // Responce data.
            console.log('Status on Post API');
            console.log(response);
           // Swal('Added', '', 'success');
            // this.router.navigate(['/managecustomer']);
            // window.scrollTo(0, 0);
            // this.presentToast('Added To Favourite');
            this.getOrders();
          },
          error => {
            // Error Message
            // Swal(
            //   error.statusText,
            //   error._body,
            //   'error'
            // );
            console.log('Error in data load.');
            // Doyour stuff here
          }
        );
        return 0;


    }




async presentToast(msg: any) {
  const toast = await this.toastController.create({
    message: msg,
    // position: 'top',
    // animated: true,
    duration: 2000
  });
  toast.present();
}
}
