import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private route: Router
  ) {
    this.initializeApp();

    // if(localStorage.getItem('isLoggedin') != null){


    // }else{

    // }
    if (localStorage.getItem('islogin') === 'true') {
      if (localStorage.getItem('type') === 'FIRM') {
        this.route.navigate(['/vendors/vendor-home']);
      } else if (localStorage.getItem('type') === 'CUSTOMER') {
        this.route.navigate(['/tabs/tab1']);
      } else if (localStorage.getItem('type') === 'DELIVERY_PERSON') {
        this.route.navigate(['/deliverypools/deliverypool-home']);
      }
    } else {
      this.route.navigate(['/index/login']);
    }

  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  // isLoggedin() {
  //   return localStorage.getItem('isLoggedin') != null;
  // }
// this.splashScreen.show();

// this.splashScreen.hide();

}
